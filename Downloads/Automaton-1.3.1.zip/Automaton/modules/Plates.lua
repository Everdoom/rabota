Automaton_Plates = Automaton:NewModule("Plates", "AceEvent-2.0", "AceDebug-2.0")
local module = Automaton_Plates

if locale == "koKR" then
	L = {
		["Plates"] = "이름표 표시",
		["Shows name plates in combat."] = "전투 상태시 이름을 표시합니다.",
	}
elseif locale == "esES" then
	L = {
		["Plates"] = "Placas",
		["Shows name plates in combat."] = "Muestra las placas identificativas cuando est\195\161s en combate",
	}
elseif locale == "zhTW" then
	L = {
		["Plates"] = "敵對名稱面板",
		["Shows name plates in combat."] = "戰鬥時顯示敵對名稱面板",
	}
elseif locale == "zhCN" then
	L = {
		["Shows name plates in combat."] = "战斗中显示敌方姓名板",
	}
end
L = setmetatable(L or {}, { __index = function(self, key) rawset(self, key, key) return key end })

module.description = L["Shows name plates in combat."]
module.options = {
}

function module:OnInitialize()
	self.db = Automaton:AcquireDBNamespace("Plates")
	Automaton:RegisterDefaults("Plates", "profile", {
		disabled = true,
    })
	Automaton:SetDisabledAsDefault(self, "Plates")
	self:RegisterOptions(self.options)
end

function module:OnEnable()
	self:RegisterEvent("PLAYER_REGEN_ENABLED")
	self:RegisterEvent("PLAYER_REGEN_DISABLED")
end

if select(4, GetBuildInfo()) < 30000 then
	-- Live

	function module:PLAYER_REGEN_ENABLED()
		HideNameplates()
		NAMEPLATES_ON = false
	end

	function module:PLAYER_REGEN_DISABLED()
		ShowNameplates()
		NAMEPLATES_ON = true
	end
	
else
	-- WotLK beta
	function module:PLAYER_REGEN_ENABLED()
		SetCVar("nameplateShowEnemies", 0)
		NAMEPLATES_ON = false
	end

	function module:PLAYER_REGEN_DISABLED()
		SetCVar("nameplateShowEnemies", 1)
		NAMEPLATES_ON = true
	end

end