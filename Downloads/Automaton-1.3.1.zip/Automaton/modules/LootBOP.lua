Automaton_LootBOP = Automaton:NewModule("LootBOP", "AceEvent-2.0", "AceDebug-2.0")
local module = Automaton_LootBOP

local L
local locale = GetLocale()
if locale == "koKR" then
	L = {
	    ["LootBOP"] = "획득 메시지 무시",
		["Ignore BOP confirm message when not in a party or raid"] = "파티 또는 공격대시 아이템 획득 확인 메시지를 무시합니다.",
	}
elseif locale == "esES" then
	L = {
	    ["LootBOP"] = "Bot\195\173n BoP",
		["Ignore BOP confirm message when not in a party or raid"] = "Ignora los mensajes de confirmaci\195\179n de BoP ('se liga al cogerlo') cuando no est\195\161s en un grupo o banda",
	}
elseif locale == "zhTW" then
	L = {
		["LootBOP"] = "拾取綁定",
		["Ignore BOP confirm message when not in a party or raid"] = "當不在隊伍時自動忽略拾取綁定信息確認",
	}
elseif locale == "zhCN" then
	L = {
		["Ignore BOP confirm message when not in a party or raid"] = "当你不在队伍或者团队中时忽略“拾取绑定”提示信息",
	}
end
L = setmetatable(L or {}, { __index = function(self, key) rawset(self, key, key) return key end })

module.description = L["Ignore BOP confirm message when not in a party or raid"]
module.options = {
}

function module:OnInitialize()
    self.db = Automaton:AcquireDBNamespace("LootBOP")
	Automaton:RegisterDefaults('LootBOP', 'profile', {
		disabled = true,
	})
	Automaton:SetDisabledAsDefault(self, "LootBOP")
	self:RegisterOptions(self.options)
end

function module:OnEnable()
	self:RegisterEvent("LOOT_BIND_CONFIRM")
end

function module:LOOT_BIND_CONFIRM(slot)
	if GetNumPartyMembers() == 0 then
		self:Debug("Looting...")
		ConfirmLootSlot(slot)
		StaticPopup_Hide("LOOT_BIND")
	end
end