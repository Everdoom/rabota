﻿local L = AceLibrary("AceLocale-2.2"):new("Automaton_Gossip")

L:RegisterTranslations("koKR", function() return {
	["Gossip"] = "잡담 무시",
	["Automatically complete quests and skip gossip text"] = "퀘스트 자동 완료 및 NPC와의 잡담을 무시합니다.",

	--------------
	-- Gossip Text
	--------------
	["<Place my hand on the orb.>"] = "보주에 손을 얹습니다.",
	["<Touch the unstable rift crystal.>"] = "불안정한 균열의 수정을 건드립니다.",
	["Grant me your mark, mighty ancient."] = "제게 당신의 표식을 주십시오. 강인한 고대인이시여.",
	["Grant me your mark, wise ancient."] = "제게 당신의 표식을 주십시오. 지혜로운 고대인이시여.",
	["I need a pack of incendiary bombs."] = "화염 폭탄 자루를 주세요.",
	["I require a chrono-beacon, Sa'at."] = "시간의 봉화가 필요합니다, 사트.",
	["I'm ready to go to Durholde Keep."] = "던홀드 요새로 갈 준비가 끝났습니다.",
	["Naturalist, please grant me your boon."] = "Naturalist, please grant me your boon.",
	["Please take me to the master's lair."] = "저를 데려다 주세요.",
	["Thank you, Stable Master. Please take the animal."] = "이 늑대를 맡아주시면 감사하겠습니다.",
	["Trick or Treat!"] = "사탕 하나 주면 안잡아먹지!",
	["With pleasure. These things stink!"] = "With pleasure. These things stink!",
}
end)
