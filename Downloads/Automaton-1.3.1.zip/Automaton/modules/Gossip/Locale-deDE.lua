﻿local L = AceLibrary("AceLocale-2.2"):new("Automaton_Gossip")

L:RegisterTranslations("deDE", function() return {
	["Gossip"] = "Gossip",
	["Automatically complete quests and skip gossip text"] = "Komplettiert automatsch Quests und überspringt gossip Text",

	--------------
	-- Gossip Text
	--------------
	["<Place my hand on the orb.>"] = "<Place my hand on the orb.>",
	["<Touch the unstable rift crystal.>"] = "<Touch the unstable rift crystal.>",
	["Grant me your mark, mighty ancient."] = "Mächtiges Urtum, bitte gewährt mir Euer Mal.",
	["Grant me your mark, wise ancient."] = "Gewährt mir Euer Mal, weises Urtum.",
	["I need a pack of incendiary bombs."] = "I need a pack of incendiary bombs.",
	["I require a chrono-beacon, Sa'at."] = "Ich brauche ein Chronosignal, Sa'at.",
	["I'm ready to go to Durholde Keep."] = "I'm ready to go to Durholde Keep.",
	["Naturalist, please grant me your boon."] = "Naturalist, bitte gewährt mir Euer Mal.",
	["Please take me to the master's lair."] = "Please take me to the master's lair.",
	["Thank you, Stable Master. Please take the animal."] = "Thank you, Stable Master. Please take the animal.",
	["Trick or Treat!"] = "Süsses oder Saures!",
	["With pleasure. These things stink!"] = "With pleasure. These things stink!",
}
end)
