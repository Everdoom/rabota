local L = AceLibrary("AceLocale-2.2"):new("Automaton_Gossip")

L:RegisterTranslations("esES", function() return {
	["Gossip"] = "Chismorreo",
	["Automatically complete quests and skip gossip text"] = "Completa misiones y salta el texto de forma autom\195\161tica" ,
}
end)
