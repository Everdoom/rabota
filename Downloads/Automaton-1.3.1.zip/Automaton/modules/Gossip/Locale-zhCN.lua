--By Kurax Kuang
--update by wangmarsfa
--Credits to Thomas Mo(昏睡墨鱼)@CWDG
local L = AceLibrary("AceLocale-2.2"):new("Automaton_Gossip")

L:RegisterTranslations("zhCN", function() return {
	["Gossip"] = "Gossip",
	["Automatically complete quests and skip gossip text"] = "还任务时自动跳过闲聊窗口，直接完成任务",

	--------------
	-- Gossip Text
	--------------
	["<Place my hand on the orb.>"] = "<Place my hand on the orb.>", -- Need translation, BWL entrance
	["<Touch the unstable rift crystal.>"] = "<Touch the unstable rift crystal.>", -- Need translation, MC entrance
	["Grant me your mark, mighty ancient."] = "赐予我你的印记吧，强大的古树。",
	["Grant me your mark, wise ancient."] = "赐予我你的印记吧，睿智的古树。",
	["I need a pack of incendiary bombs."] = "我需要燃烧弹包。",
	["I require a chrono-beacon, Sa'at."] = "我需要一个时空道标，萨艾特。",
	["I would be grateful for any aid you can provide, Priestess."] = "I would be grateful for any aid you can provide, Priestess.",
	["I'm ready to go to Durholde Keep."] = "我准备好去敦霍尔德城堡了。",
	["Naturalist, please grant me your boon."] = "Naturalist, please grant me your boon.", -- Need translation, in SP, before the final boss
	["Please take me to the master's lair."] = "请带我去主人的巢穴。",
	["Thank you, Stable Master. Please take the animal."] = "Thank you, Stable Master. Please take the animal.", -- Need translation, AV quest
	["Transport me to the Molten Core, Lothos."] = "Transport me to the Molten Core, Lothos.",
	["Trick or Treat!"] = "不给糖就捣乱！",
	["With pleasure. These things stink!"] = "With pleasure. These things stink!", -- Need translation, AV quest
}
end)