--Chinese Local : CWDG Translation Team Thomas Mo (昏睡墨鱼)
--$Rev:
--$Date:

local L = AceLibrary("AceLocale-2.2"):new("Automaton_Gossip")

L:RegisterTranslations("zhTW", function() return {
	["Gossip"] = "Gossip",
	["Automatically complete quests and skip gossip text"] = "還任務時自動跳過閒聊窗口，直接完成任務",

	--------------
	-- Gossip Text
	--------------
	["<Place my hand on the orb.>"] = "<Place my hand on the orb.>",
	["<Touch the unstable rift crystal.>"] = "<Touch the unstable rift crystal.>",
	["Grant me your mark, mighty ancient."] = "Grant me your mark, mighty ancient.",
	["Grant me your mark, wise ancient."] = "Grant me your mark, wise ancient.",
	["I need a pack of incendiary bombs."] = "I need a pack of incendiary bombs.",
	["I require a chrono-beacon, Sa'at."] = "I require a chrono-beacon, Sa'at.",
	["I'm ready to go to Durholde Keep."] = "I'm ready to go to Durholde Keep.",
	["Naturalist, please grant me your boon."] = "Naturalist, please grant me your boon.",
	["Please take me to the master's lair."] = "Please take me to the master's lair.",
	["Thank you, Stable Master. Please take the animal."] = "Thank you, Stable Master. Please take the animal.",
	["Trick or Treat!"] = "Trick or Treat!",
	["With pleasure. These things stink!"] = "With pleasure. These things stink!",
}
end )