local L = AceLibrary("AceLocale-2.2"):new("Automaton_Gossip")
local B = LibStub("LibBabble-Quests-3.0")
local BL = B:GetLookupTable()

--[[

  If you would like to add your own Quests, Gossips, or Items, simply follow the format provided.
  There are a few things to remember when adding new items: if you use L[], you must also add
  to the localization file (Locale-enUS.lua or whatever). You do not have to use the L[] at all,
  you could simply add ["This is my thing"], instead. All quests are tables, and must be
  ["Quest Name"] = {} if it is to always attempt to hand in the quest, or
  ["Quest Name"] = {
    items = { <itemid> = 1 }, -- where <itemid> is replaced by the item's id
                         -- number following is how many of the item are required
    priority = 1,  -- higher priority -value- will ensure one quest gets handed in before another
  },               -- IE, 2 is a HIGHER priority than 1. This is not the olympics.

  I will not help if you break this file. Experiment at your own risk. Either way, I encourage you
  to let me know of anything you think should appear here, I would be happy to expand it.

--]]

function Automaton_Gossip:GetGossipData()
return {
	["banker"] = {},
	["battlemaster"] = {},
	["taxi"] = {},
	["vendor"] = {},
	["trainer"] = {},
	["gossip"] = {
		L["<Touch the unstable rift crystal.>"],
		L["<Place my hand on the orb.>"],
		L["Transport me to the Molten Core, Lothos."],
		L["Thank you, Stable Master. Please take the animal."],
		L["With pleasure. These things stink!"],
		L["Trick or Treat!"],
		L["Grant me your mark, wise ancient."],
		L["Grant me your mark, mighty ancient."],
		L["Please take me to the master's lair."],
		L["I need a pack of incendiary bombs."],
		L["I'm ready to go to Durholde Keep."],
		L["I require a chrono-beacon, Sa'at."],
		L["Naturalist, please grant me your boon."],
		L["I would be grateful for any aid you can provide, Priestess."],
	},
}
end

function Automaton_Gossip:GetQuestData()
return {
-- Fishing
	[BL["Apprentice Angler"]] = {
		items = { [19807] = 5 } -- Speckled Tastyfish
	},

-- Alterac Valley quests
	[BL["Empty Stables"]] = {},
	[BL["Ram Hide Harnesses"]] = {
		items = { [17642] = 1 } -- Alterac Ram Hide
	},
	[BL["Ram Riding Harnesses"]] = {
		items = { [17643] = 1 } -- Frostwolf Hide
	},
	[BL["More Booty!"]] = {
		items = { [17422] = 20 } -- Armor Scraps
	},
	[BL["More Armor Scraps"]] = {
		items = { [17422] = 20 } -- Armor Scraps
	},
	[BL["Coldtooth Supplies"]] = {
		items = { [17542] = 10 } -- Coldtooth Supplies
	},
	[BL["Irondeep Supplies"]] = {
		items = { [17522] = 10 } -- Irondeep Supplies
	},
	[BL["Lokholar the Ice Lord"]] = {
		items = { [17306] = 1 }, -- Stormpike Soldier's Blood,
		priority = 1,
	},
	[BL["A Gallon of Blood"]] = {
		items = { [17306] = 5 }, -- Stormpike Soldier's Blood,
		priority = 2,
	},
	[BL["Ivus the Forest Lord"]] = {
		items = { [17423] = 1 }, -- Storm Crystal,
		priority = 1,
	},
	[BL["Crystal Cluster"]] = {
		items = { [17423] = 5 }, -- Storm Crystal,
		priority = 2,
	},
	[BL["Call of Air - Slidore's Fleet"]] = {
		items = { [17502] = 1 } -- Frostwolf Soldier's Medal
	},
	[BL["Call of Air - Vipore's Fleet"]] = {
		items = { [17503] = 1 } -- Frostwolf Lieutenant's Medal
	},
	[BL["Call of Air - Ichman's Fleet"]] = {
		items = { [17504] = 1 } -- Frostwolf Commander's Medal
	},
	[BL["Call of Air - Guse's Fleet"]] = {
		items = { [17326] = 1 } -- Stormpike Soldier's Flesh
	},
	[BL["Call of Air - Jeztor's Fleet"]] = {
		items = { [17327] = 1 } -- Stormpike Lieutenant's Flesh
	},
	[BL["Call of Air - Mulverick's Fleet"]] = {
		items = { [17328] = 1 } -- Stormpike Commander's Flesh
	},

-- Felwood salves
	[BL["Salve via Gathering"]] = {
		items = { [11514] = 4 }, -- Fel Creep,
		priority = 1,
	},
	[BL["Salve via Mining"]] = {
		items = { [11513] = 4 }, -- Tainted Vitriol,
		priority = 1,
	},
	[BL["Salve via Skinning"]] = {
		items = { [11512] = 5 }, -- Patch of Tainted Skin,
		priority = 1,
	},
	[BL["Salve via Hunting"]] = {
		items = { [11515] = 6 }, -- Corrupted Soul Shard,
		priority = 1,
	},
	[BL["Salve via Disenchanting"]] = {
		items = { [11174] = 1 }, -- Lesser Nether Essence,
		priority = 1,
	},

-- Felwood plants
	[BL["Corrupted Whipper Root"]] = {
		items = { [11516] = 3 } -- Cenarion Plant Salve
	},
	[BL["Corrupted Songflower"]] = {
		items = { [11516] = 2 } -- Cenarion Plant Salve
	},
	[BL["Corrupted Windblossom"]] = {
		items = { [11516] = 2 } -- Cenarion Plant Salve
	},
	[BL["Corrupted Night Dragon"]] = {
		items = { [11516] = 4 } -- Cenarion Plant Salve
	},

-- Ravenholdt
	[BL["Syndicate Emblems"]] = {
		items = { [17124] = 1 } -- Syndicate Emblem
	},

-- Thorium Shells -> Thorium Arrows Quest
	[BL["A Fair Trade"]] = {
		items = { [15997] = 200 } -- Thorium Shells,
	},

-- Cenarion
	[BL["Encrypted Twilight Texts"]] = {
		items = { [20404] = 10 } -- Encrypted Twilight Text
	},

-- Argent Dawn
	[BL["Minion's Scourgestones"]] = {
		items = { [12840] = 20 } -- Minion's Scourgestone,
	},
	[BL["Invader's Scourgestones"]] = {
		items = { [12841] = 10 } -- Invader's Scourgestone
	},
	[BL["Corruptor's Scourgestones"]] = {
		items = { [12843] = 1 } -- Corruptor's Scourgestone
	},
	[BL["Bone Fragments"]] = {
		items = { [22526] = 30 } -- Bone Fragments
	},
	[BL["Crypt Fiend Parts"]] = {
		items = { [22525] = 30 } -- Crypt Fiend Parts
	},
	[BL["Core of Elements"]] = {
		items = { [22527] = 30 } -- Core of Elements
	},
	[BL["Dark Iron Scraps"]] = {
		items = { [22528] = 30 } -- Dark Iron Scraps
	},

-- Timbermaw
	[BL["Feathers for Grazle"]] = {
		items = { [21377] = 5 } -- Deadwood Headdress Feather
	},
	[BL["Feathers for Nafien"]] = {
		items = { [21377] = 5 } -- Deadwood Headdress Feather
	},
	[BL["Beads for Salfa"]] = {
		items = { [21383] = 5 } -- Winterfall Spirit Beads
	},

-- Cauldron quests
	[BL["Gahrron's Withering Cauldron"]] = {
		items = {
			[13320] = 1, -- Arcane Quickener
			[13354] = 4, -- Ectoplasmic Resonator
			[14047] = 4, -- Runecloth
		},
	},
	[BL["Writhing Haunt Cauldron"]] = {
		items = {
			[13320] = 1, -- Arcane Quickener
			[13356] = 5, -- Somatic Intensifier
			[14047] = 4, -- Runecloth
		},
	},
	[BL["Felstone Field Cauldron"]] = {
		items = {
			[13320] = 1, -- Arcane Quickener
			[13357] = 6, -- Osseous Agitator
			[14047] = 4, -- Runecloth
		},
	},
	[BL["Dalson's Tears Cauldron"]] = {
		items = {
			[13320] = 1, -- Arcane Quickener
			[13356] = 5, -- Somatic Intensifier
			[14047] = 4, -- Runecloth
		},
	},

-- Gadgetzan
	[BL["Water Pouch Bounty"]] = {
		items = { [8483] = 5 } -- Wastewander Water Pouch
	},

-- Thorium Brotherhood
	[BL["Gaining Acceptance"]] = {
		items = { [18945] = 4 } -- Dark Iron Residue
	},
	[BL["Restoring Fiery Flux Supplies via Kingsblood"]] = {
		items = { 
			[3356] = 4, -- Kingsblood
			[18944] = 2, -- Incendosaur Scale
			[3857] = 1, -- Coal
		}
	},
	[BL["Restoring Fiery Flux Supplies via Iron"]] = {
		items = { 
			[3575] = 4, -- Iron Bar
			[18944] = 2, -- Incendosaur Scale
			[3857] = 1, -- Coal
		}
	},
	[BL["Restoring Fiery Flux Supplies via Heavy Leather"]] = {
		items = { 
			[4234] = 4, -- Heavy Leather
			[18944] = 2, -- Incendosaur Scale
			[3857] = 1, -- Coal
		}
	},
	[BL["Favor Amongst the Brotherhood, Dark Iron Ore"]] = {
		items = { [11370] = 10 } -- Dark Iron Ore
	},
	[BL["Favor Amongst the Brotherhood, Blood of the Mountain"]] = {
		items = { [11382] = 1 } -- Blood of the Mountain
	},
	[BL["Favor Amongst the Brotherhood, Core Leather"]] = {
		items = { [17012] = 2 } -- Core Leather
	},
	[BL["Favor Amongst the Brotherhood, Fiery Core"]] = {
		items = { [17010] = 1 } -- Fiery Core
	},
	[BL["Favor Amongst the Brotherhood, Lava Core"]] = {
		items = { [17011] = 1 } -- Lava Core
	},

-- City faction
	[BL["Additional Runecloth"]] = {
		items = { [14047] = 20 } -- Runecloth
	},

-- Wildhammer faction
--	[BL["Troll Necklace Bounty"]] = {
--		items = { [9259] = 5 } -- Troll Tribal Necklace
--	},

-- E'ko quests
	[BL["Chillwind E'ko"]] = {
		items = { [12434] = 3 } -- Chillwind E'ko Item
	},
	[BL["Frostmaul E'ko"]] = {
		items = { [12436] = 3 } -- Frostmaul E'ko Item
	},
	[BL["Frostsaber E'ko"]] = {
		items = { [12430] = 3 } -- Frostsaber E'ko Item
	},
	[BL["Ice Thistle E'ko"]] = {
		items = { [12435] = 3 } -- Ice Thistle E'ko Item
	},
	[BL["Shardtooth E'ko"]] = {
		items = { [12432] = 3 } -- Shardtooth E'ko Item
	},
	[BL["Wildkin E'ko"]] = {
		items = { [12433] = 3 } -- Wildkin E'ko Item
	},
	[BL["Winterfall E'ko"]] = {
		items = { [12431] = 3 } -- Winterfall E'ko
	},

-- Zul'Gurub quests
	[BL["Zulian, Razzashi, and Hakkari Coins"]] = {
		items = {
			[19698] = 1, -- Zulian Coin
			[19699] = 1, -- Razzashi Coin
			[19700] = 1, -- Hakkari Coin
		}
	},
	[BL["Gurubashi, Vilebranch, and Witherbark Coins"]] = {
		items = {
			[19701] = 1, -- Gurubashi Coin
			[19702] = 1, -- Vilebranch Coin
			[19703] = 1, -- Witherbark Coin
		}
	},
	[BL["Sandfury, Skullsplitter, and Bloodscalp Coins"]] = {
		items = {
			[19704] = 1, -- Sandfury Coin
			[19705] = 1, -- Skullsplitter Coin
		 	[19706] = 1, -- Bloodscalp Coin
		}
	},

--[[
--  Burning Crusade
--]]

--Shattrath City

	--Scryers
	[BL["More Firewing Signets"]] = {
		items = { [29426] = 10 }, -- Firewing Signet,
		priority = 4
	},
	[BL["Single Firewing Signet"]] = {
		items = { [29426] = 1 }, -- Firewing Signet,
		priority = 3
	},
	[BL["More Sunfury Signets"]] = {
		items = { [30810] = 10 }, -- Sunfury Signet,
		priority = 2
	},
	[BL["Single Sunfury Signet"]] = {
		items = { [30810] = 1 }, -- Sunfury Signet,
		priority = 1
	},
	[BL["Arcane Tomes"]] = {
		items = { [29739] = 1 }, -- Arcane Tome
	},
	

	--Aldor
	[BL["Strained Supplies"]] = {
		items = { [25802] = 8 }, -- Dreadfang Venom Sac,
	},
	[BL["More Marks of Kil'jaeden"]] = {
		items = { [29425] = 10 }, -- Mark of Kil'jaeden,
		priority = 4
	},
	[BL["Single Mark of Kil'jaeden"]] = {
		items = { [29425] = 1 }, -- Mark of Kil'jaeden,
		priority = 3
	},
	[BL["More Marks of Sargeras"]] = {
		items = { [30809] = 10 }, -- Mark of Sargeras,
		priority = 2
	},
	[BL["Single Mark of Sargeras"]] = {
		items = { [30809] = 1 }, -- Mark of Sargeras,
		priority = 1
	},
	[BL["Fel Armaments"]] = {
		items = { [29740] = 1 }, -- Fel Armament
	},

-- Zangarmarsh

	-- Cenarion Refuge
	[BL["Identify Plant Parts"]] = {
		items = { [24401] = 10 } -- Unidentified Plant Parts
	},
	[BL["Coilfang Armaments"]] = {
		items = { [24368] = 1 } -- Coilfang Armaments
	},

	-- Sporeggar
	[BL["More Spore Sacs"]] = {
		items = { [24290] = 10 } -- Mature Spore Sac
	},
	[BL["More Tendrils!"]] = {
		items = { [24291] = 6 } -- Bog Lord Tendril
	},
	[BL["More Glowcaps"]] = {
		items = { [24245] = 10 } -- Glowcap
	},
	[BL["Bring Me Another Shrubbery!"]] = {
		items = { [24246] = 5 } -- Sanguine Hibiscus
	},
	[BL["More Fertile Spores"]] = {
		items = { [24449] = 10 } -- Fertile Spore
	},

-- Terokkar Forest

	-- Spinebreaker Hold
	[BL["More Arakkoa Feathers"]] = {
		items = { [25719] = 30 } -- Arakkoa Feather
	},
	-- Skettis
	[BL["More Shadow Dust"]] = {
		items = { [32388] = 6 } -- Shadow Dust
	},

-- Nagrand
	
	-- Garadar
	[BL["More Warbeads!"]] = {
		items = { [25433] = 10 } -- Obsidian Warbeads
	},

	-- Halaa
	[BL["Oshu'gun Crystal Powder"]] = {
		-- Oshu'gun Crystal Powder Sample
		itemsAlliance = { [26043] = 20 },
		itemsHorde = { [26042] = 20 }
	},

	-- Aeris Landing
	[BL["More Heads Full of Ivory"]] = {
		items = { [25463] = 3 } -- Pair of Ivory Tusks
	},
	[BL["More Crystal Fragments"]] = {
		items = { [25416] = 10 } -- Oshu'gun Crystal Fragment
	},
	[BL["More Obsidian Warbeads"]] = {
		items = { [25433] = 10 } -- Obsidian Warbeads
	},
	
-- Netherstorm

	-- Area 52
	[BL["Another Heap of Ethereals"]] = {
		items = { [29209] = 10 } -- Zaxxis Insignia
	},
	-- Ethereum
	[BL["Ethereum Prisoner I.D. Catalogue"]] = {
		items = { [31957] = 1 } -- Ethereum Prisoner I.D. Tag
	},

-- Shadowmoon Valley

	-- Netherwing Ledge
	[BL["Accepting All Eggs"]] = {
		items = { [32506] = 1 } -- Netherwing Egg
	},

--[[
--  WotLK
--]]

	-- Sons of Hodir rep
	[BL["Hodir's Tribute"]] = {
		items = { [42780] = 10 } -- Relic of Ulduar
	},

--[[		I deactiveted those because WotLK is coming and I guess(!) most players will hoard MoH's and
		it would be very unfortunate if they get turned in accidently.

-- 2.4 Battleground mark turn-in

	-- Alliance
  [BL["Concerted Efforts"] ] = {
  	items = {
  	 	[20560] = 1, -- Alterac Valley Mark of Honor
			[20559] = 1, -- Arathi Basin Mark of Honor
			[20558] = 1, -- Warsong Gulch Mark of Honor
			[29024] = 1, -- Eye of the Storm Mark of Honor
  	}
  },
  
  -- Horde
  [BL["For Great Honor"] ] = {
  	items = {
  	 	[20560] = 1, -- Alterac Valley Mark of Honor
			[20559] = 1, -- Arathi Basin Mark of Honor
			[20558] = 1, -- Warsong Gulch Mark of Honor
			[29024] = 1, -- Eye of the Storm Mark of Honor
  	}
  },
	--]]  
}
end
