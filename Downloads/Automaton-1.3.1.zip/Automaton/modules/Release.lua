Automaton_Release = Automaton:NewModule("Release", "AceEvent-2.0", "AceDebug-2.0")
local module = Automaton_Release

local L
local locale = GetLocale()
if locale == "koKR" then
	L = {
	    ["Release"] = "전장 부활",
		["Automatically release to ghost after dying in a battleground"] = "전장에서 죽은 후에 유령상태시 자동으로 부활합니다.",
	}
elseif locale == "esES" then
	L = {
	    ["Release"] = "Liberar",
		["Automatically release to ghost after dying in a battleground"] = "Libera autom\195\161ticamente tu esp\195\173ritu cuando mueres en un campo de batalla",
	}
elseif locale == "zhTW" then
	L = {
		["Release"] = "釋放靈魂",
		["Automatically release to ghost after dying in a battleground"] = "戰場中自動釋放靈魂",
	}
elseif locale == "zhCN" then
	L = {
		["Automatically release to ghost after dying in a battleground"] = "战场中死后自动释放灵魂",
	}
end
L = setmetatable(L or {}, { __index = function(self, key) rawset(self, key, key) return key end })

module.description = L["Automatically release to ghost after dying in a battleground"]
module.options = {
}

function module:OnInitialize()
	self:RegisterOptions(self.options)
end

function module:OnEnable()
	self:RegisterEvent("PLAYER_DEAD")
end

function module:PLAYER_DEAD()
	if MiniMapBattlefieldFrame.status == "active" then
		self:Debug("Releasing...")
		RepopMe()
	end
end