Public Class Setting
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents NumDim As System.Windows.Forms.NumericUpDown
    Friend WithEvents Ok As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.NumDim = New System.Windows.Forms.NumericUpDown()
        Me.Ok = New System.Windows.Forms.Button()
        CType(Me.NumDim, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'NumDim
        '
        Me.NumDim.Location = New System.Drawing.Point(4, 8)
        Me.NumDim.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumDim.Name = "NumDim"
        Me.NumDim.Size = New System.Drawing.Size(84, 20)
        Me.NumDim.TabIndex = 0
        Me.NumDim.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Ok
        '
        Me.Ok.Location = New System.Drawing.Point(100, 4)
        Me.Ok.Name = "Ok"
        Me.Ok.Size = New System.Drawing.Size(68, 28)
        Me.Ok.TabIndex = 1
        Me.Ok.Text = "Ok"
        '
        'Setting
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(174, 38)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Ok, Me.NumDim})
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "Setting"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "������ ���������"
        CType(Me.NumDim, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region
    Public Event Upgrade(ByVal Dimension As Short)
    Private Sub NumDim_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumDim.ValueChanged
        RaiseEvent Upgrade(NumDim.Value + 1) ' �������� HTTP-������ ������� ����� :-)
    End Sub

    Private Sub Ok_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Ok.Click
        Me.Close()
    End Sub
End Class
