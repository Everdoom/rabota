'������� ���:
'
' 1. ����
'  ���������� ���������� ��� ����� � �������� "1",
'  ��� ����� �� ������� �������� ��� �������� � �������� ������.  
'
' 2.  ��������
'   ����� �� ����� ������� ���� ������� ����!!!!!!! 
' 
' Copyright by �������� �.�.   ahs@pisem.net
Public Class MainForm
    Inherits System.Windows.Forms.Form
#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem5 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem7 As System.Windows.Forms.MenuItem
    Friend WithEvents MnuRestart As System.Windows.Forms.MenuItem
    Friend WithEvents MnuSet As System.Windows.Forms.MenuItem
    Friend WithEvents MnuExit As System.Windows.Forms.MenuItem
    Friend WithEvents MnuAbout As System.Windows.Forms.MenuItem
    Friend WithEvents MnuG1 As System.Windows.Forms.MenuItem
    Friend WithEvents MnuG2 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem4 As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.MenuItem1 = New System.Windows.Forms.MenuItem
        Me.MnuRestart = New System.Windows.Forms.MenuItem
        Me.MenuItem5 = New System.Windows.Forms.MenuItem
        Me.MnuG1 = New System.Windows.Forms.MenuItem
        Me.MnuG2 = New System.Windows.Forms.MenuItem
        Me.MenuItem4 = New System.Windows.Forms.MenuItem
        Me.MnuSet = New System.Windows.Forms.MenuItem
        Me.MenuItem7 = New System.Windows.Forms.MenuItem
        Me.MnuExit = New System.Windows.Forms.MenuItem
        Me.MnuAbout = New System.Windows.Forms.MenuItem
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1, Me.MnuAbout})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MnuRestart, Me.MenuItem5, Me.MnuG1, Me.MnuG2, Me.MenuItem4, Me.MnuSet, Me.MenuItem7, Me.MnuExit})
        Me.MenuItem1.Text = "����"
        '
        'MnuRestart
        '
        Me.MnuRestart.Index = 0
        Me.MnuRestart.Text = "�������"
        '
        'MenuItem5
        '
        Me.MenuItem5.Index = 1
        Me.MenuItem5.Text = "-"
        '
        'MnuG1
        '
        Me.MnuG1.Checked = True
        Me.MnuG1.Index = 2
        Me.MnuG1.Text = "����"
        '
        'MnuG2
        '
        Me.MnuG2.Index = 3
        Me.MnuG2.Text = "��������"
        '
        'MenuItem4
        '
        Me.MenuItem4.Index = 4
        Me.MenuItem4.Text = "-"
        '
        'MnuSet
        '
        Me.MnuSet.Index = 5
        Me.MnuSet.Text = "���������"
        '
        'MenuItem7
        '
        Me.MenuItem7.Index = 6
        Me.MenuItem7.Text = "-"
        '
        'MnuExit
        '
        Me.MnuExit.Index = 7
        Me.MnuExit.Text = "�����"
        '
        'MnuAbout
        '
        Me.MnuAbout.Index = 1
        Me.MnuAbout.Text = "� ���������"
        '
        'MainForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
        Me.ClientSize = New System.Drawing.Size(150, 140)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.MaximizeBox = False
        Me.Menu = Me.MainMenu1
        Me.Name = "MainForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "�������"

    End Sub

#End Region
    Private Game As Boolean '����� �� ������ ��� ����. ���-��� �� ���� ���, �� ����� � Boolean
    Private WithEvents Setting As New Setting()
    Private Dimension As Short = 2
    '���� ������� �� ��������
    Private ImageOff As New Bitmap(Me.GetType, "k1.bmp")
    Private ImageOn As New Bitmap(Me.GetType, "k2.bmp")
    Private Image15 As New Bitmap(Me.GetType, "k15.bmp") '������� ����� ��� ��������
    Private ArG1(2, 2) As Boolean
    Private ArG2(2, 2) As Short
    Protected Overrides Sub OnPaint(ByVal e As System.Windows.Forms.PaintEventArgs)

        ' � ��� ����� ������������ ����  :-)))))))))

        Dim Countx, County As Short
        'Me.ClientSize = New Size(40 * (Dimension + 1) + 12, 40 * (Dimension + 1) + 12)
        e.Graphics.DrawRectangle(New Pen(Color.Blue, 4), New Rectangle(2, 2, 40 * (Dimension + 1) + 8, 40 * (Dimension + 1) + 8))
        Select Case Game
            Case False
                For Countx = 0 To Dimension
                    For County = 0 To Dimension
                        If ArG1(Countx, County) Then
                            e.Graphics.DrawImage(ImageOff, New Point(6 + Countx * 40, 6 + County * 40))
                        Else
                            e.Graphics.DrawImage(ImageOn, New Point(6 + Countx * 40, 6 + County * 40))
                        End If
                    Next
                Next
            Case True
                For Countx = 0 To Dimension
                    For County = 0 To Dimension
                        If ArG2(Countx, County) <> 0 Then
                            e.Graphics.DrawImage(Image15, New Point(6 + Countx * 40, 6 + County * 40))
                            e.Graphics.DrawString(ArG2(Countx, County), Me.Font, Brushes.Yellow, 6 + Countx * 40 + 10, 6 + County * 40 + 12)
                        End If
                    Next
                Next
        End Select

    End Sub
    Private Sub Rotate(ByVal x As Double, ByVal y As Double)
        Select Case Game '�������� ��� ����
            Case False ' ����
                Dim Count As Short
                For Count = 0 To Dimension
                    ArG1(Count, y) = Not ArG1(Count, y) '�������� ��������
                    ArG1(x, Count) = Not ArG1(x, Count) '�������� ��������
                Next
                ArG1(x, y) = Not ArG1(x, y)
                '�������������� ������ ������������ ����� �����
                Invalidate(New Rectangle(6 + x * 40, 6, 40, 40 * (Dimension + 1)))
                Invalidate(New Rectangle(6, 6 + y * 40, 40 * (Dimension + 1), 40))
            Case True    '��������

                '���� ������ ����� ��������� ����� � �����������
                If x > 0 Then
                    If ArG2(x - 1, y) = 0 Then
                        ArG2(x - 1, y) = ArG2(x, y)
                        ArG2(x, y) = 0
                        Invalidate(New Rectangle((x - 1) * 40 + 6, y * 40 + 6, 80, 40))
                    End If
                End If
                If y > 0 Then
                    If ArG2(x, y - 1) = 0 Then
                        ArG2(x, y - 1) = ArG2(x, y)
                        ArG2(x, y) = 0
                        Invalidate(New Rectangle(x * 40 + 6, (y - 1) * 40 + 6, 40, 80))
                    End If
                End If
                If x < Dimension Then
                    If ArG2(x + 1, y) = 0 Then
                        ArG2(x + 1, y) = ArG2(x, y)
                        ArG2(x, y) = 0
                        Invalidate(New Rectangle(x * 40 + 6, y * 40 + 6, 80, 40))
                    End If
                End If
                If y < Dimension Then
                    If ArG2(x, y + 1) = 0 Then
                        ArG2(x, y + 1) = ArG2(x, y)
                        ArG2(x, y) = 0
                        Invalidate(New Rectangle(x * 40 + 6, y * 40 + 6, 40, 80))
                    End If
                End If
        End Select
        If Scan() Then
            MessageBox.Show("���������� � �������!")
        End If
    End Sub
    Private Sub _MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseDown
        If e.X > 6 And e.X < 6 + 40 * (Dimension + 1) And e.Y > 6 And e.Y < 6 + 40 * (Dimension + 1) Then
            Dim Tempx, Tempy As Double
            '����������� ����������
            Tempx = Int((e.X - 6) / 40)
            Tempy = Int((e.Y - 6) / 40)
            Call Rotate(Tempx, Tempy)
        End If
    End Sub
    Private Sub DimensionChanged(ByVal NewDimension As Short) Handles Setting.Upgrade
        ' ���-�� ����� ��������� ���� ����� :-)
        Dimension = NewDimension
        ReDim ArG1(Dimension, Dimension)
        ReDim ArG2(Dimension, Dimension)
        Call Random()
        Invalidate()
    End Sub
    Private Sub Random()
        Dim Countx, County As Short
        '������� ����������
        Select Case Game
            Case False ' ����
                For Countx = 0 To Dimension
                    For County = 0 To Dimension
                        ArG1(Countx, County) = Rnd() > 0.5
                    Next
                Next
            Case True ' ��������
                Dim Rand As New Random()
                Dim Temp As Integer
                Dim Used((Dimension + 1) ^ 2) As Boolean
                For Countx = 0 To Dimension
                    For County = 0 To Dimension
                        While Used(Temp)
                            Temp = Rand.Next(0, (Dimension + 1) ^ 2)
                        End While
                        Used(Temp) = True
                        ArG2(Countx, County) = Temp
                    Next
                Next
        End Select
        Invalidate()
    End Sub
    Private Function Scan() As Boolean
        Dim Countx, County, Count As Short
        '��������, ����� ��� ���-�� ������ ��� ���������� ����
        Select Case Game
            Case False
                For Countx = 0 To Dimension
                    For County = 0 To Dimension
                        If ArG1(Countx, County) Then Return False
                    Next
                Next
                Return True
            Case True
                For County = 0 To Dimension
                    For Countx = 0 To Dimension
                        If Countx = Dimension And County = Dimension Then Return True
                        If ArG2(Countx, County) <> Count + 1 Then Return False
                        Count += 1
                    Next
                Next
                Return True
        End Select
    End Function
    Private Sub MnuSet_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MnuSet.Click
        Setting.ShowDialog()
    End Sub
    Private Sub MainForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call Random()
    End Sub
    Private Sub MnuExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MnuExit.Click
        Application.Exit()
    End Sub
    Private Sub MnuRestart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MnuRestart.Click
        Call Random()
    End Sub
    Private Sub MnuAbout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MnuAbout.Click
        MessageBox.Show("Copyright � " & vbCrLf & " Domnikov V.V." & vbCrLf & "       Aquarius HomeSoft" & vbCrLf & "       2004", "������ ���� v.1.0�", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub
    Private Sub MnuG2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MnuG2.Click, MnuG1.Click
        MnuG2.Checked = Not MnuG2.Checked
        MnuG1.Checked = Not MnuG1.Checked
        Game = MnuG2.Checked
        Call Random()
        Invalidate()
    End Sub
End Class
