======================================
FTP Password Recovery v1.1.0.0
Copyright (c) 2002 Aleksandar Boros

http://www.gsmblog.com/freeware/fpr/
======================================


Description
===========
FTP Password Recovery emulates a local FTP server and thereby allows you to
recover the FTP login password for any FTP account you may have, as long as
it is cached inside an FTP client program. FTP passwords are commonly cached
by FTP programs (WSFTTP,CuteFTP etc.), so you don't have to enter them each
time, but they are usually masked by asterisk or not shown at all. To
recover those passwords, you can use the client, that holds the cached
password, and connect to FTP Password Recovery, which will then reveal the
password it receives from the FTP program. The program can only recover the
passwords that are stored on your computer


System Requirements
===================
* Windows operating system: Windows 95/98/ME, Windows NT, Windows 2000 or Windows XP. 
* Some of Visual Basic 6 libraries 


Versions History
================
02/07/2004 Version 1.1.0.0: I had to move the site to another provider. 
                            Download and contact information update.
09/18/2002 Version 1.0.0.0: First release.


License
=======
This utility is released as freeware for personal use. 
Do not use this utility for illegal activity, and do not use it for getting passwords
of a computer that is not yours.
If you distribute this utility, you must include the executable file and the readme file
in the distribution package, without any modification !


Disclaimer
==========
The software is provided "AS IS" without any warranty, either expressed or implied,
including, but not limited to, the implied warranties of merchantability and fitness
for a particular purpose. The author will not be liable for any special, incidental,
consequential or indirect damages due to loss of data or any other reason. 


Using FTP Password Recovery
=================================
- Start FTP Password Recovery
- Open your FTP Client (like CuteFTP, LeechFTP)
- Open connection properties
- Write down current FTP server address
- Change this into 127.0.0.1
- Repeat this for all necessary servers
- Confirm changes
- Go online (if neccessary)
- Connect to FTP server
- Passwords will appear in program window
- Change back original FTP server address
- Close this program ;-)


Possible problems
=================
Problem 1:
During program start you can receive following message:
Component 'MSWINSCK.OCX' or one of its dependencies not
correctly registered;a file is missing or invalid.

Solution 1: 
- Download mswinsck.ocx from  http://www.gsmblog.com/freeware/vblib/mswinsck.zip
- Extract ZIP archive to \windows\system or \winnt\system32 folder.
- go to command prompt
- change current folder to \windows\system or \winnt\system32
- do: regsvr32 mswinsck.ocx

Problem 2:
During program start you can receive following message:
Can't initialize port 21! Program will close now.

Solution 2: 
This will happen if some other program is using port 21.
Close all programs which can use port 21 like 3rd party FTP server.

Feedback
========
If you have any problem, suggestion, comment, or you found a bug in my utility, 
you can send a message to pwdrecovery@hotpop.com


