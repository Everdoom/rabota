﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace RotatingGradient
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        private Single m_Theta = 0;
        private Single m_Delta = 10;

        private void picCanvas_Paint(object sender, PaintEventArgs e)
        {
            
            Rectangle rect = 
                new Rectangle(-3, -3, picCanvas.ClientSize.Width + 6, picCanvas.ClientSize.Height + 6);
            System.Drawing.Drawing2D.LinearGradientBrush br = 
                new System.Drawing.Drawing2D.LinearGradientBrush(rect, Color.Red, Color.Blue, m_Theta);
            e.Graphics.Clear(picCanvas.BackColor);
            e.Graphics.FillRectangle(br, this.ClientRectangle);
            br.Dispose();
            m_Theta += m_Delta;

            StringFormat strformat = new StringFormat();
            strformat.Alignment = StringAlignment.Center;
            strformat.LineAlignment = StringAlignment.Center;

            e.Graphics.DrawString("Градиент", this.Font,
                Brushes.Black,
                picCanvas.ClientSize.Width / 2,
                picCanvas.ClientSize.Height / 2,
                strformat);
        }

        private void tmrRotate_Tick(object sender, EventArgs e)
        {
            picCanvas.Invalidate();
        }

       
    }
}

