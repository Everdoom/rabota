﻿namespace ProgressIndicatorTest
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.trackBarCircleSize = new System.Windows.Forms.TrackBar();
            this.trackBarProgressIndicatorSize = new System.Windows.Forms.TrackBar();
            this.buttonStart = new System.Windows.Forms.Button();
            this.buttonStop = new System.Windows.Forms.Button();
            this.trackBarSpeed = new System.Windows.Forms.TrackBar();
            this.buttonResetValues = new System.Windows.Forms.Button();
            this.buttonChangeColor = new System.Windows.Forms.Button();
            this.colorDialog = new System.Windows.Forms.ColorDialog();
            this.labelAnimationSpeed = new System.Windows.Forms.Label();
            this.labelCircleSize = new System.Windows.Forms.Label();
            this.labelControlSize = new System.Windows.Forms.Label();
            this.progressIndicator = new ProgressControls.ProgressIndicator();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarCircleSize)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarProgressIndicatorSize)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarSpeed)).BeginInit();
            this.SuspendLayout();
            // 
            // trackBarCircleSize
            // 
            this.trackBarCircleSize.Location = new System.Drawing.Point(63, 12);
            this.trackBarCircleSize.Minimum = 1;
            this.trackBarCircleSize.Name = "trackBarCircleSize";
            this.trackBarCircleSize.Size = new System.Drawing.Size(360, 45);
            this.trackBarCircleSize.TabIndex = 0;
            this.trackBarCircleSize.Value = 1;
            this.trackBarCircleSize.Scroll += new System.EventHandler(this.trackBarCircleSize_Scroll);
            // 
            // trackBarProgressIndicatorSize
            // 
            this.trackBarProgressIndicatorSize.Location = new System.Drawing.Point(12, 79);
            this.trackBarProgressIndicatorSize.Maximum = 344;
            this.trackBarProgressIndicatorSize.Name = "trackBarProgressIndicatorSize";
            this.trackBarProgressIndicatorSize.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trackBarProgressIndicatorSize.Size = new System.Drawing.Size(45, 344);
            this.trackBarProgressIndicatorSize.SmallChange = 8;
            this.trackBarProgressIndicatorSize.TabIndex = 1;
            this.trackBarProgressIndicatorSize.TickFrequency = 16;
            this.trackBarProgressIndicatorSize.Scroll += new System.EventHandler(this.trackBarProgressIndicatorSize_Scroll);
            // 
            // buttonStart
            // 
            this.buttonStart.Location = new System.Drawing.Point(429, 12);
            this.buttonStart.Name = "buttonStart";
            this.buttonStart.Size = new System.Drawing.Size(103, 23);
            this.buttonStart.TabIndex = 3;
            this.buttonStart.Text = "Start Animation";
            this.buttonStart.UseVisualStyleBackColor = true;
            this.buttonStart.Click += new System.EventHandler(this.buttonStart_Click);
            // 
            // buttonStop
            // 
            this.buttonStop.Location = new System.Drawing.Point(429, 41);
            this.buttonStop.Name = "buttonStop";
            this.buttonStop.Size = new System.Drawing.Size(103, 23);
            this.buttonStop.TabIndex = 4;
            this.buttonStop.Text = "Stop Animation";
            this.buttonStop.UseVisualStyleBackColor = true;
            this.buttonStop.Click += new System.EventHandler(this.buttonStop_Click);
            // 
            // trackBarSpeed
            // 
            this.trackBarSpeed.Location = new System.Drawing.Point(63, 429);
            this.trackBarSpeed.Maximum = 100;
            this.trackBarSpeed.Minimum = 1;
            this.trackBarSpeed.Name = "trackBarSpeed";
            this.trackBarSpeed.Size = new System.Drawing.Size(360, 45);
            this.trackBarSpeed.TabIndex = 5;
            this.trackBarSpeed.TickFrequency = 10;
            this.trackBarSpeed.TickStyle = System.Windows.Forms.TickStyle.TopLeft;
            this.trackBarSpeed.Value = 1;
            this.trackBarSpeed.Scroll += new System.EventHandler(this.trackBarSpeed_Scroll);
            // 
            // buttonResetValues
            // 
            this.buttonResetValues.Location = new System.Drawing.Point(429, 91);
            this.buttonResetValues.Name = "buttonResetValues";
            this.buttonResetValues.Size = new System.Drawing.Size(103, 23);
            this.buttonResetValues.TabIndex = 6;
            this.buttonResetValues.Text = "Reset Values";
            this.buttonResetValues.UseVisualStyleBackColor = true;
            this.buttonResetValues.Click += new System.EventHandler(this.buttonResetValues_Click);
            // 
            // buttonChangeColor
            // 
            this.buttonChangeColor.Location = new System.Drawing.Point(429, 144);
            this.buttonChangeColor.Name = "buttonChangeColor";
            this.buttonChangeColor.Size = new System.Drawing.Size(103, 23);
            this.buttonChangeColor.TabIndex = 7;
            this.buttonChangeColor.Text = "Change Color";
            this.buttonChangeColor.UseVisualStyleBackColor = true;
            this.buttonChangeColor.Click += new System.EventHandler(this.buttonChangeColor_Click);
            // 
            // labelAnimationSpeed
            // 
            this.labelAnimationSpeed.AutoSize = true;
            this.labelAnimationSpeed.Location = new System.Drawing.Point(429, 343);
            this.labelAnimationSpeed.Name = "labelAnimationSpeed";
            this.labelAnimationSpeed.Size = new System.Drawing.Size(90, 13);
            this.labelAnimationSpeed.TabIndex = 8;
            this.labelAnimationSpeed.Text = "Animation Speed:";
            // 
            // labelCircleSize
            // 
            this.labelCircleSize.AutoSize = true;
            this.labelCircleSize.Location = new System.Drawing.Point(429, 366);
            this.labelCircleSize.Name = "labelCircleSize";
            this.labelCircleSize.Size = new System.Drawing.Size(59, 13);
            this.labelCircleSize.TabIndex = 9;
            this.labelCircleSize.Text = "Circle Size:";
            // 
            // labelControlSize
            // 
            this.labelControlSize.AutoSize = true;
            this.labelControlSize.Location = new System.Drawing.Point(429, 388);
            this.labelControlSize.Name = "labelControlSize";
            this.labelControlSize.Size = new System.Drawing.Size(66, 13);
            this.labelControlSize.TabIndex = 10;
            this.labelControlSize.Text = "Control Size:";
            // 
            // progressIndicator
            // 
            this.progressIndicator.Location = new System.Drawing.Point(63, 63);
            this.progressIndicator.Name = "progressIndicator";
            this.progressIndicator.Size = new System.Drawing.Size(360, 360);
            this.progressIndicator.TabIndex = 2;
            this.progressIndicator.Text = "progressIndicator1";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(547, 476);
            this.Controls.Add(this.labelControlSize);
            this.Controls.Add(this.labelCircleSize);
            this.Controls.Add(this.labelAnimationSpeed);
            this.Controls.Add(this.buttonChangeColor);
            this.Controls.Add(this.buttonResetValues);
            this.Controls.Add(this.trackBarSpeed);
            this.Controls.Add(this.buttonStop);
            this.Controls.Add(this.buttonStart);
            this.Controls.Add(this.progressIndicator);
            this.Controls.Add(this.trackBarProgressIndicatorSize);
            this.Controls.Add(this.trackBarCircleSize);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.Text = "Progress Indicator Test";
            this.Load += new System.EventHandler(this.MainForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.trackBarCircleSize)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarProgressIndicatorSize)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarSpeed)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TrackBar trackBarCircleSize;
        private System.Windows.Forms.TrackBar trackBarProgressIndicatorSize;
        private ProgressControls.ProgressIndicator progressIndicator;
        private System.Windows.Forms.Button buttonStart;
        private System.Windows.Forms.Button buttonStop;
        private System.Windows.Forms.TrackBar trackBarSpeed;
        private System.Windows.Forms.Button buttonResetValues;
        private System.Windows.Forms.Button buttonChangeColor;
        private System.Windows.Forms.ColorDialog colorDialog;
        private System.Windows.Forms.Label labelAnimationSpeed;
        private System.Windows.Forms.Label labelCircleSize;
        private System.Windows.Forms.Label labelControlSize;
    }
}

