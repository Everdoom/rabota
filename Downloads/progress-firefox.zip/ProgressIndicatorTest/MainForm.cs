﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace ProgressIndicatorTest
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void EnableTrackBars(bool enable)
        {
            trackBarSpeed.Enabled = enable;
            trackBarProgressIndicatorSize.Enabled = enable;
            trackBarCircleSize.Enabled = enable;
            buttonResetValues.Enabled = enable;
            buttonChangeColor.Enabled = enable;
        }

        private void RefreshLabels()
        {
            labelAnimationSpeed.Text = string.Format("Animation Speed: {0}", progressIndicator.AnimationSpeed);
            labelCircleSize.Text = string.Format("Circle Size: {0}", progressIndicator.CircleSize);
            labelControlSize.Text = string.Format("Control Size: {0}", progressIndicator.Width);
        }

        private void EraseLabels()
        {
            labelAnimationSpeed.Text = "Animation Speed:";
            labelCircleSize.Text = "Circle Size:";
            labelControlSize.Text = "Control Size:";
        }

        private void trackBarProgressIndicatorSize_Scroll(object sender, EventArgs e)
        {
            int value = (360 - trackBarProgressIndicatorSize.Value);
            progressIndicator.Size = new Size(value, value);
            RefreshLabels();
        }

        private void trackBarCircleSize_Scroll(object sender, EventArgs e)
        {
            progressIndicator.CircleSize = trackBarCircleSize.Value / 10.0F;
            RefreshLabels();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            trackBarProgressIndicatorSize.Value = 644 - (progressIndicator.Width - 16);
            trackBarCircleSize.Value = (int)(progressIndicator.CircleSize * 10);
            trackBarSpeed.Value = progressIndicator.AnimationSpeed;
            EnableTrackBars(false);
            //progressIndicator.CircleColor = Color.Red; // Цвет кружочков
        }

        private void buttonStart_Click(object sender, EventArgs e)
        {
            progressIndicator.Start();
            EnableTrackBars(true);
            RefreshLabels();
        }

        private void buttonStop_Click(object sender, EventArgs e)
        {
            progressIndicator.Stop();
            EnableTrackBars(false);
            EraseLabels();
        }

        private void trackBarSpeed_Scroll(object sender, EventArgs e)
        {
            progressIndicator.AnimationSpeed = trackBarSpeed.Value;
            RefreshLabels();
        }

        private void buttonResetValues_Click(object sender, EventArgs e)
        {
            progressIndicator.CircleColor = Color.FromArgb(20, 20, 20);
            progressIndicator.Size = new Size(360, 360);
            progressIndicator.CircleSize = 1.0F;
            progressIndicator.AnimationSpeed = 75;
            trackBarSpeed.Value = progressIndicator.AnimationSpeed;
            trackBarProgressIndicatorSize.Value = 344 - (progressIndicator.Width - 16);
            trackBarCircleSize.Value = (int)(progressIndicator.CircleSize * 10);
            RefreshLabels();
        }

        private void buttonChangeColor_Click(object sender, EventArgs e)
        {
            if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                progressIndicator.CircleColor = colorDialog.Color;
            }
        }
    }
}
