﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;


namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }
        public WMPLib.WindowsMediaPlayer WMP = new WMPLib.WindowsMediaPlayer();
        int sum = 0;
       public int hp = 100;
        int maxhp = 100;
        int DPS = 0;
        int wave = 1;
        private void Form1_Load(object sender, EventArgs e)
        {

        }

    
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            sum = sum + 100;
            return;
          //  label3.Text = sum.ToString();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
          //  Wave();
            sum++;
            label3.Text ="Gold: "+ sum.ToString();
            hp = hp - DPS;
            label4.Text ="Волна"+ wave + " HP: " + hp.ToString();
            if (hp<=1)
                        
                    {
                hp = 170 * wave;
                // Random rnd = new Random();
                // rnd(1, 4);
            
                
                wave++;
            }
            else{ }
        }

      

    

        private void Form1_Load_1(object sender, EventArgs e)
        {
          
        }

        private Bitmap rotateImage(Bitmap input, float angle)
        {
            Bitmap result = new Bitmap(input.Width, input.Height);
            Graphics g = Graphics.FromImage(result);
            g.TranslateTransform((float)input.Width / 2, (float)input.Height / 2);
            g.RotateTransform(angle);
            g.TranslateTransform(-(float)input.Width / 2, -(float)input.Height / 2);
            g.DrawImage(input, new Point(0, 0));
            return result;
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
           hp=hp-DPS;
            // label4.Text ="HP: "+ hp.ToString();
            return;
        }

        private void label4_Click(object sender, EventArgs e)
        {
            //  Resource1.st.RotateFlip(RotateFlipType.Rotate180FlipY);
             // pictureBox2.Image.RotateFlip(RotateFlipType.Rotate180FlipY);
            //  pictureBox2.Image ==
            //   DrawString();
           // pictureBox2.Image.Dispose();

                }
        private void DrawString()
        {
            
            System.Drawing.Graphics formGraphics = this.CreateGraphics();
           
            string drawString = hp.ToString();
            //"Sample Text";
            System.Drawing.Font drawFont = new System.Drawing.Font(
                "Arial", 16);
            System.Drawing.SolidBrush drawBrush = new
                System.Drawing.SolidBrush(System.Drawing.Color.Black);
            float x = 170.0f;
            float y = 50.0f;
            //formGraphics.Clear(Color.Black);
            formGraphics.DrawString(drawString, drawFont, drawBrush, x, y);
            drawFont.Dispose();
            drawBrush.Dispose();
            formGraphics.Dispose();
           // formGraphics.Clear(Color.White);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WMP.URL = @"sound.mp3"; // файл музыкальный
            WMP.settings.volume = 100; // меняя значение можно регулировать громкость
            WMP.controls.play(); // Старт
          //  WMP.controls.stop(); // Стоп
          //  WMP.close();
        }

       
        private void hScrollBar1_Scroll_1(object sender, ScrollEventArgs e)
        {
            label5.Text = hScrollBar1.Value.ToString();
            DPS = hScrollBar1.Value;
        }
        private void Wave()
        {
            if(hp<=0)
            {maxhp= wave*3                    ;
                wave++;
            }
        }

    }
}
